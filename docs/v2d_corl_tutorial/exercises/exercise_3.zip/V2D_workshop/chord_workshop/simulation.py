# SPDX-License-Identifier: Apache-2.0
"""Newton CPU replay and policy evaluation for the calibrated flask task."""
import json, time
from pathlib import Path
from dataclasses import dataclass
from functools import lru_cache
import numpy as np
import newton
import warp as wp
from scipy.spatial.transform import Rotation
from threadpoolctl import threadpool_limits

ASSETS = Path(__file__).parent / 'assets'
wp.config.log_level = wp.LOG_WARNING
wp.init()


def unique(q):
    return q if q[0] >= 0 else -q


def relative_quat(current, target):
    a, b = np.asarray(current), np.asarray(target)
    return np.r_[a[0]*b[0]+a[1:]@b[1:], a[0]*b[1:]-b[0]*a[1:]-np.cross(a[1:],b[1:])]


@lru_cache(maxsize=1)
def _model():
    with wp.ScopedDevice('cpu'):
        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        builder.add_mjcf(str(ASSETS/'model/flask_newton.xml'), ctrl_direct=True,
                         collapse_fixed_joints=False)
        return builder.finalize(device='cpu')


class _FlaskSolver(newton.solvers.SolverMuJoCo):
    """Newton solver using native CPU physics and retained arm compensation."""
    def __init__(self, model, metadata):
        super().__init__(model, use_mujoco_cpu=True, use_mujoco_contacts=True,
            solver='newton', integrator='implicitfast', cone='pyramidal',
            iterations=100, ls_iterations=50, impratio=20.,
            tolerance=9.99999993922529e-9, ls_tolerance=.009999999776482582,
            update_data_interval=0, ls_parallel=False, nconmax=4096, njmax=16384)
        # Native state remains authoritative between resets. Newton's step()
        # exports each result to Newton State without a float32 round-trip back
        # into the native integrator on every 5 ms substep.
        self.bias_actuators = np.asarray(metadata['bias_actuator_ids'], dtype=int)
        self.bias_dofs = np.asarray(metadata['bias_dof_ids'], dtype=int)
        self.bias = np.zeros(self.mj_model.nv)
        # Keep the same calibration and imported mesh frames as the CPU-Warp
        # bundle; update the native model that Newton actually steps.
        with np.load(ASSETS/'model/calibration.npz', allow_pickle=False) as values:
            for name in values.files:
                target = getattr(self.mj_model, name)
                source = values[name]
                if target.shape != source.shape:
                    raise ValueError(f'Calibration shape mismatch for {name}: {target.shape} vs {source.shape}')
                target[:] = source
        self.mj_model.opt.timestep = .005
        assert self.use_mujoco_cpu and model.device.is_cpu

    def _apply_mjc_control(self, model, state, control, data):
        # Newton maps its Control and external-force buffers to the backend.
        super()._apply_mjc_control(model, state, control, data)
        # Compensate the arm bias through motor commands; never apply forces
        # directly to the flask. Integration remains in Newton's step().
        mujoco = self._mujoco
        mujoco.mj_kinematics(self.mj_model, data)
        mujoco.mj_comPos(self.mj_model, data)
        mujoco.mj_comVel(self.mj_model, data)
        mujoco.mj_rne(self.mj_model, data, 0, self.bias)
        data.ctrl[self.bias_actuators] += self.bias[self.bias_dofs] / self.mj_model.actuator_gainprm[self.bias_actuators, 0]


class Kinematics:
    def __init__(self):
        self.metadata = json.loads((ASSETS/'model/runtime.json').read_text())
        self.model = _model()
        self.state = self.model.state()
        self.body_ids = {name.rsplit('/',1)[-1]: i for i,name in enumerate(self.model.body_label)}
        self.object_id = self.body_ids['obj_4111539686391_object']
        with np.load(ASSETS/'reference.npz', allow_pickle=False) as f:
            self.reference = {k:f[k] for k in f.files}
        self.ref_q = self.reference['qpos']
        self.num_frames = len(self.ref_q)
        self.set_pose(self.ref_q[0])

    def set_pose(self, qpos, velocity=None):
        q = np.asarray(qpos,dtype=np.float32).copy()
        q[61:65] = q[[62,63,64,61]]
        self.state.joint_q.assign(q)
        if velocity is None:
            self.state.joint_qd.zero_()
        else:
            self.state.joint_qd.assign(np.asarray(velocity,dtype=np.float32))
        newton.eval_fk(self.model,self.state.joint_q,self.state.joint_qd,self.state)
        self._read_state()

    def _read_state(self):
        self.qpos = self.state.joint_q.numpy().copy()
        self.qpos[61:65] = self.qpos[[64,61,62,63]]
        self.qvel = self.state.joint_qd.numpy().copy()
        poses = self.state.body_q.numpy()
        self.positions = poses[:,:3].copy()
        self.quaternions = poses[:,[6,3,4,5]].copy()
        self.quaternions /= np.linalg.norm(self.quaternions,axis=1,keepdims=True)
        self.rotations = Rotation.from_quat(self.quaternions[:,[1,2,3,0]]).as_matrix()

@dataclass
class Rollout:
    mode: str
    qpos: np.ndarray
    frames: np.ndarray
    object_error: np.ndarray
    elapsed_seconds: float
    terminated: bool = False
    reason: str = ''
    actions: np.ndarray | None = None
    fps: float = 20.

    def summary(self):
        return {'mode': self.mode, 'frames': len(self.frames),
                'simulated_seconds': round((len(self.frames)-1)/self.fps, 2),
                'compute_seconds': round(self.elapsed_seconds, 2),
                'max_object_position_error_m': round(float(self.object_error.max()), 4),
                'termination': self.reason or 'reference completed', 'VOC': 0}


class Simulation(Kinematics):
    def __init__(self, *, delay_steps=0):
        if not 0 <= delay_steps <= 12:
            raise ValueError('Additional target delay must be in [0, 12] physics steps.')
        super().__init__()
        self.solver = None
        self.delay_steps = int(delay_steps)
        self.s = {k: np.asarray(v) for k,v in self.metadata['solver'].items()}
        self.a = {k: np.asarray(v, dtype=np.float32) for k,v in self.metadata['action'].items()}
        self.lower = np.asarray(self.metadata['joint_lower'][:58], dtype=np.float32)
        self.upper = np.asarray(self.metadata['joint_upper'][:58], dtype=np.float32)
        self.arm_ids = np.asarray(self.metadata['arm_ids'])
        self.finger_ids = np.asarray(self.metadata['finger_ids'])
        self.wrist_ids = np.array([self.body_ids['Marvin_pro_809_'+side+'_hand_C_MC'] for side in ('right','left')])
        self.motor_lag = self.s['lag_steps'].astype(int)
        self.motor_capacity = int(self.motor_lag.max()) + 1
        self.wrist_pairs = np.array([[5,6],[34,35]])
        self.reset()

    def _ensure_solver(self):
        if self.solver is None:
            with wp.ScopedDevice('cpu'):
                self.solver = _FlaskSolver(self.model,self.metadata['solver'])
                self.next_state = self.model.state()
                self.control = self.model.control()
            self._reset_solver()

    def _reset_solver(self):
        with wp.ScopedDevice('cpu'):
            solver = self.solver
            solver._mujoco.mj_resetData(solver.mj_model, solver.mj_data)
            solver._update_mjc_data(solver.mj_data, self.model, self.state)
            self._workspace()
            solver._mujoco.mj_forward(solver.mj_model, solver.mj_data)
            solver._step = 0
            self.state.clear_forces()
            self.next_state.clear_forces()
            self.control.mujoco.ctrl.zero_()

    def reset(self, frame=0):
        if not 0 <= frame < self.num_frames:
            raise ValueError('Reference frame is outside the bundled sequence.')
        self.frame = int(frame)
        self.set_pose(self.ref_q[frame])
        self.raw = np.zeros(58, dtype=np.float32)
        self.filtered = np.zeros(58, dtype=np.float32)
        self.target = np.zeros(58, dtype=np.float32)
        self.initialized = False
        self.motor_history = np.tile(self.qpos[:58], (self.motor_capacity, 1))
        self.motor_cursor = 0
        self.delay_history = np.zeros((13,58), dtype=np.float32)
        self.delay_cursor = 0
        self.delay_pushes = 0
        if self.solver is not None:
            self._reset_solver()
        return self.observation()

    def _workspace(self):
        s = self.s
        bounds = s['_physical_bounds']
        fe = self.state.joint_q.numpy()[s['_physical_fe_ids'].astype(int)]
        active = (fe >= bounds[:,0]) & (fe < bounds[:,1])
        self.solver.mj_model.tendon_range[s['_physical_tendon_ids'].astype(int)] = np.where(active[:,None],bounds[:,2:],[-1e6,1e6])

    def process_action(self, action):
        action = np.asarray(action, dtype=np.float32)
        if action.shape != (58,) or not np.isfinite(action).all():
            raise ValueError('Expected 58 finite normalized actions.')
        action = np.clip(action, -1, 1)
        magnitude = np.abs(action)
        self.raw = action / ((1-magnitude) + magnitude/self.a['input_scale'])
        self.filtered = np.clip(np.float32(.3)*self.filtered + np.float32(.7)*self.raw*self.a['scale'], -self.a['clip'], self.a['clip'])
        reference = self.reference['robot_target'][self.frame]
        target = np.clip(reference + self.filtered, self.lower, self.upper)
        previous = self.target if self.initialized else reference
        ema = self.a['final_target_ema']
        target = ema*previous + (1-ema)*target
        step = self.a['max_target_step']
        self.target = np.clip(target, previous-step, previous+step).astype(np.float32)
        self.initialized = True
        return self.target.copy()

    def _substep(self):
        s = self.s
        if self.delay_pushes == 0:
            self.delay_history[:] = self.target
        self.delay_history[self.delay_cursor] = self.target
        lag = min(self.delay_steps, self.delay_pushes)
        request = self.delay_history[(self.delay_cursor-lag)%13].copy()
        self.delay_cursor = (self.delay_cursor+1)%13
        self.delay_pushes += 1
        for j6,j7 in self.wrist_pairs:
            limit = max(0, min(np.pi/2, np.deg2rad(110.5)-1.025*abs(request[j6]))-np.deg2rad(1.5))
            request[j7] = np.clip(request[j7], -limit, limit)
        self.motor_history[self.motor_cursor] = request
        request = self.motor_history[(self.motor_cursor-self.motor_lag)%self.motor_capacity, np.arange(58)]
        self.motor_cursor = (self.motor_cursor+1)%self.motor_capacity
        control = np.zeros(self.control.mujoco.ctrl.shape,dtype=np.float32)
        control[s['position_ids'].astype(int)] = request
        self.control.mujoco.ctrl.assign(control)
        self._workspace()
        thresholds = s['static_sliding_thresholds'][:self.model.joint_dof_count]
        ids = np.flatnonzero(thresholds[:,2] > 0)
        fc, fs, speed = thresholds[ids].T
        self.solver.mj_model.dof_frictionloss[ids] = np.where(np.abs(self.solver.mj_data.qvel[ids]) < speed, fs, fc)
        self.solver.step(self.state,self.next_state,self.control,None,.005)
        self.state,self.next_state = self.next_state,self.state

    def step(self, action):
        self._ensure_solver()
        self.process_action(action)
        for _ in range(10):
            self._substep()
        self.frame = min(self.frame+1, self.num_frames-1)
        self._read_state()
        return self.observation()

    def observation(self):
        f = self.frame
        out = np.zeros(332, dtype=np.float32)
        positions = self.positions[self.wrist_ids]
        quats = np.array([unique(q) for q in self.quaternions[self.wrist_ids]])
        out[:6] = positions.ravel()
        out[6:14] = quats.ravel()
        out[14:28] = self.qpos[self.arm_ids]
        out[28:42] = self.qvel[self.arm_ids]
        out[42:56] = self.reference['robot_target'][f,self.arm_ids] - self.qpos[self.arm_ids]
        finger = self.qpos[self.finger_ids]
        low,high = self.lower[self.finger_ids],self.upper[self.finger_ids]
        out[56:100] = 2*(finger-low)/(high-low)-1
        out[100:144] = self.qvel[self.finger_ids]
        out[144:147] = self.positions[self.object_id]
        out[147:151] = self.quaternions[self.object_id]
        for i,side in enumerate(['right','left']):
            rot = self.rotations[self.wrist_ids[i]].reshape(3,3)
            delta = self.reference[side+'_wrist_pos_w'][f] - positions[i]
            quat = relative_quat(quats[i], unique(self.reference[side+'_wrist_quat_w'][f]))
            out[151+7*i:158+7*i] = np.r_[rot.T@delta,quat]
        out[165:209] = self.reference['robot_target'][f,self.finger_ids]-finger
        rot = self.rotations[self.object_id].reshape(3,3)
        out[209:212] = rot.T@(self.ref_q[f,58:61]-self.positions[self.object_id])
        out[212:216] = relative_quat(self.quaternions[self.object_id], unique(self.ref_q[f,61:65]))
        out[216:274] = self.raw
        out[274:332] = self.target
        return out

    def errors(self):
        position = float(np.linalg.norm(self.positions[self.object_id] - self.ref_q[self.frame,58:61]))
        q1,q2 = self.quaternions[self.object_id],self.ref_q[self.frame,61:65]
        angle = float(2*np.arccos(np.clip(abs(np.dot(q1,q2)),0,1)))
        wrist = max(float(np.linalg.norm(self.positions[b]-self.reference[s+'_wrist_pos_w'][self.frame]))
                    for b,s in zip(self.wrist_ids,['right','left']))
        return position, angle, wrist

    @threadpool_limits.wrap(limits=1, user_api='blas')
    def run(self, policy=None, *, max_steps=None, stop_on_failure=True, progress=None):
        """Compute a new rollout; no recorded trajectory is loaded by this method."""
        self._ensure_solver()
        obs = self.reset()
        count = min(self.num_frames-1, max_steps if max_steps is not None else self.num_frames-1)
        states,frames,errors,actions = [self.qpos.copy()],[0],[self.errors()[0]],[]
        t = time.perf_counter(); reason = ''; failed = False
        for i in range(count):
            action = np.zeros(58,dtype=np.float32) if policy is None else policy(obs)
            obs = self.step(action)
            states.append(self.qpos.copy()); frames.append(self.frame)
            pos,ang,wrist = self.errors(); errors.append(pos); actions.append(action)
            if not np.isfinite(self.qpos).all():
                reason='non-finite simulation state';failed=True;break
            if stop_on_failure and (pos>.1 or ang>.5 or wrist>.15):
                reason=f'tracking threshold at {self.frame/20:.2f}s (object {pos:.3f}m, {ang:.3f}rad; wrist {wrist:.3f}m)'
                failed=True; break
            if progress and (i%100==0 or i==count-1):progress(i+1,count)
        if not failed and count < self.num_frames-1:reason='bounded preview finished'
        return Rollout('dynamics / zero residual / VOC=0' if policy is None else 'live pretrained policy / VOC=0',
                       np.asarray(states),np.asarray(frames),np.asarray(errors),time.perf_counter()-t,
                       failed,reason,np.asarray(actions))

    def kinematic(self):
        return Rollout('kinematic reference',self.ref_q.copy(),np.arange(self.num_frames),
                       np.zeros(self.num_frames),0.)
