# SPDX-License-Identifier: Apache-2.0
"""Five slide-aligned V2D workshop examples, executable on a laptop CPU."""
import atexit
from pathlib import Path
import numpy as np
from IPython.display import display,HTML
from .simulation import Simulation
from .policy import Policy
from .contacts import wrench_support,load_frame
from .viewer import Viewer,font_css


class Workshop:
    def __init__(self):
        self.viewers={}
        self.policy=Policy()
        self.root=Path(__file__).resolve().parents[1]
        display(HTML(font_css()))
        atexit.register(self.close)
        print('V2D workshop · Tianji/Sharpa · flask P0003_cbee62a7_seg013')
        print('Newton CPU dynamics + NumPy policy. All assets are local; VOC = 0.')

    def _viewer(self,key,title):
        if key in self.viewers:self.viewers[key].close()
        view=Viewer(title);self.viewers[key]=view
        return view

    def reference_replay(self):
        result=Simulation().kinematic()
        self._viewer('reference','1 · Kinematic reference').playback(result).show()
        return result

    def dynamics_replay(self, *, delay_steps=0):
        result=Simulation(delay_steps=delay_steps).run(stop_on_failure=False)
        print(result.summary())
        self._viewer('dynamics','2 · Dynamics · no VOC').playback(result).show()
        return result

    def contacts(self):
        self._viewer('contacts','3 · Contacts → wrench support').contact_scene().show(height=700)
        return load_frame(250,mu=.1)

    def collection_preview(self, *, steps=3):
        """Inspect bounded rollout collection. This is explicitly not optimizer training."""
        if not isinstance(steps,int) or not 1 <= steps <= 10:
            raise ValueError('Workshop collection preview is capped at ten control steps.')
        result=Simulation().run(self.policy,max_steps=steps)
        print(f'Collected {len(result.actions)} CPU transitions: observation (332,), action (58,).')
        print('No optimizer updates; pretrained weights remain unchanged.')
        return result

    def evaluate(self, *, delay_steps=0):
        result=Simulation(delay_steps=delay_steps).run(self.policy)
        print(result.summary())
        print('PASS: completed reference within configured tracking thresholds.' if not result.terminated
              else 'Tracking failure: inspect the final frame and tracking errors.')
        self._viewer('evaluation','5 · Live pretrained policy').playback(result).show()
        return result

    def close(self):
        for view in self.viewers.values():view.close()
        self.viewers.clear()
