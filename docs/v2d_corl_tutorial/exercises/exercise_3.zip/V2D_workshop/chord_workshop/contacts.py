# SPDX-License-Identifier: Apache-2.0
"""Reference contact geometry and the slide's six-dimensional support display."""
from functools import lru_cache
import numpy as np
from scipy.sparse import csr_matrix, diags
from .simulation import ASSETS

COLORS = {'left': (52,120,189), 'right': (218,135,48)}


def wrench_support(points, inward_normals, *, mu=.1, radius=.16786547, basis=None):
    """h(u)=max(0,max_i u·[f_i,(p_i×f_i)/r]); unit friction-cone rays.

    The origin permits zero contact effort. This normalizes each force ray;
    the display describes directional capability, not measured Newtons.
    """
    if not np.isfinite(mu) or mu < 0:
        raise ValueError('Friction coefficient must be finite and nonnegative.')
    if basis is None:
        with np.load(ASSETS/'contacts/wrench_data.npz') as data:basis=data['basis']
    generators=[]
    for p,n in zip(points,inward_normals):
        sign=1 if n[2]>=0 else -1
        a=-1/(sign+n[2]); b=n[0]*n[1]*a
        t1=np.array([1+sign*n[0]*n[0]*a,sign*b,-sign*n[0]])
        t2=np.array([b,sign+n[1]*n[1]*a,-n[1]])
        t1/=np.linalg.norm(t1);t2/=np.linalg.norm(t2)
        rays=[n+mu*(np.cos(t)*t1+np.sin(t)*t2) for t in np.arange(8)*np.pi/4]+[n]
        for force in rays:
            force=force/np.linalg.norm(force)
            generators.append(np.r_[force,np.cross(p,force)/radius])
    generators=np.asarray(generators).reshape(-1,6)
    support=np.maximum(0,(generators@basis.T).max(axis=0)) if len(generators) else np.zeros(len(basis))
    return support,generators


def smooth_surface(directions,support,faces):
    """Historical 80-step Taubin + two Loop refinements; zero support stays zero."""
    faces=faces.copy()
    tri=directions[faces]
    flip=np.einsum('ij,ij->i',np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]),tri[:,0])<0
    faces[flip]=faces[flip][:,::-1]
    edges=np.concatenate([faces[:,[0,1]],faces[:,[1,2]],faces[:,[2,0]]])
    adj=csr_matrix((np.ones(len(edges)*2),(np.r_[edges[:,0],edges[:,1]],np.r_[edges[:,1],edges[:,0]])),shape=(len(support),len(support)))
    adj.data[:]=1
    avg=diags(1/np.maximum(1,np.asarray(adj.sum(1)).ravel()))@adj
    vertices=directions*support[:,None];pinned=support<=1e-12
    for _ in range(80):
        vertices+=.5*(avg@vertices-vertices);vertices[pinned]=0
        vertices-=.53*(avg@vertices-vertices);vertices[pinned]=0
    for _ in range(2):
        edges=np.sort(np.concatenate([faces[:,[0,1]],faces[:,[1,2]],faces[:,[2,0]]]),axis=1)
        unique,inverse=np.unique(edges,axis=0,return_inverse=True)
        opposite=np.concatenate([faces[:,2],faces[:,0],faces[:,1]])
        edge_points=np.zeros((len(unique),3));counts=np.bincount(inverse,minlength=len(unique))
        np.add.at(edge_points,inverse,vertices[opposite])
        edge_points=.375*(vertices[unique[:,0]]+vertices[unique[:,1]])+.125*edge_points
        boundary=counts!=2
        edge_points[boundary]=(vertices[unique[boundary,0]]+vertices[unique[boundary,1]])*.5
        ep=pinned[unique].all(axis=1);edge_points[ep]=0
        a=csr_matrix((np.ones(2*len(unique)),(np.r_[unique[:,0],unique[:,1]],np.r_[unique[:,1],unique[:,0]])),shape=(len(vertices),len(vertices)))
        degree=np.asarray(a.sum(axis=1)).ravel();beta=np.where(degree==3,3/16,3/(8*np.maximum(degree,1)))
        moved=(1-degree*beta)[:,None]*vertices+beta[:,None]*(a@vertices);moved[pinned]=0
        ab,bc,ca=np.split(inverse+len(vertices),3)
        faces=np.vstack([np.column_stack([faces[:,0],ab,ca]),np.column_stack([faces[:,1],bc,ab]),np.column_stack([faces[:,2],ca,bc]),np.column_stack([ab,bc,ca])])
        vertices=np.vstack([moved,edge_points]);pinned=np.r_[pinned,ep]
    assert np.all(vertices[pinned]==0)
    return vertices,faces


@lru_cache(maxsize=1)
def _trajectory_inputs():
    with np.load(ASSETS/'contacts/trajectory_contacts.npz', allow_pickle=False) as data:
        contacts = {key: data[key] for key in data.files}
    with np.load(ASSETS/'contacts/wrench_data.npz', allow_pickle=False) as data:
        source = {key: data[key] for key in ('radius', 'basis', 'directions', 'faces')}
    return contacts, source


@lru_cache(maxsize=64)
def load_frame(frame, mu=.1):
    """Recompute support from this reference frame's annotated contacts."""
    contacts, source = _trajectory_inputs()
    count = contacts['points'].shape[1]
    if not isinstance(frame, (int, np.integer)) or not 0 <= frame < count:
        raise ValueError(f'Choose a reference frame from 0 to {count-1}.')
    result = {}
    for hand, side in enumerate(('left', 'right')):
        valid = contacts['valid'][hand, frame]
        points = contacts['points'][hand, frame, valid]
        normals = contacts['normals'][hand, frame, valid]
        support, generators = wrench_support(points, normals, mu=mu,
            radius=float(source['radius']), basis=source['basis'])
        vertices, faces = smooth_surface(source['directions'], support, source['faces'])
        result[side] = dict(points=points, normals=normals, support=support,
            generators=generators, vertices=vertices, faces=faces,
            raw_vertices=source['directions']*support[:, None])
    return result
