# SPDX-License-Identifier: Apache-2.0
"""CPU inference for the supplied FlashSAC actor, using NumPy only.

The supplied named-array export contains the pretrained inference weights.
Batch statistics are frozen. No parameters are trained or downloaded here.
"""
from pathlib import Path
import numpy as np


class Policy:
    def __init__(self, directory=None):
        directory = Path(directory or Path(__file__).parent / 'assets/policy')
        with np.load(directory / 'actor.npz', allow_pickle=False) as data:
            self.weights = {k: data[k] for k in data.files}

    def norm(self, x, name):
        w = self.weights
        return ((x - w['batch_stats/'+name+'/running_mean']) /
                np.sqrt(w['batch_stats/'+name+'/running_variance'] + np.float32(1e-5)) *
                w['params/'+name+'/unit_scale'] + w['params/'+name+'/unit_bias'])

    def __call__(self, observation):
        x = np.asarray(observation, dtype=np.float32)
        if x.shape[-1] != 332 or not np.isfinite(x).all():
            raise ValueError('Policy expects 332 finite observation values.')
        w = self.weights
        x = self.norm(x, 'input_norm') @ w['params/embed/unit_kernel']
        for i in range(2):
            b = f'block_{i}'
            residual = x
            x = x @ w[f'params/{b}/expand/unit_kernel']
            x = np.maximum(self.norm(x, b+'/expand_norm'), 0)
            x = x @ w[f'params/{b}/contract/unit_kernel']
            x = np.maximum(self.norm(x, b+'/contract_norm'), 0) + residual
        x = x / np.sqrt(np.mean(x*x, axis=-1, keepdims=True) + np.float32(1e-6))
        x *= w['params/post_norm/rms_scale']
        mean = (x @ w['params/mean/unit_kernel']) * w['params/mean/gain'] + w['params/mean_bias']
        return np.tanh(mean).astype(np.float32)
