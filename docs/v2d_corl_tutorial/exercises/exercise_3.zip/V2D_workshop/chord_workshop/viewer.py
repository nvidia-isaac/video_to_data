# SPDX-License-Identifier: Apache-2.0
"""Embedded local Viser scenes. All meshes, textures, fonts and HDRIs are local."""
import base64, threading, time
from functools import lru_cache
import numpy as np
import trimesh, viser
from scipy.spatial.transform import Rotation
from IPython.display import display, IFrame, HTML
from .simulation import ASSETS, Kinematics, relative_quat
from .contacts import COLORS, load_frame


@lru_cache(maxsize=70)
def mesh_bytes(name):
    return (ASSETS/'visuals'/name).read_bytes()


def font_css():
    font=base64.b64encode((ASSETS/'fonts/NVIDIASans_Rg.ttf').read_bytes()).decode()
    return f"<style>@font-face{{font-family:'NVIDIA Sans';src:url(data:font/ttf;base64,{font})}} body,button,input,select,textarea,p,span,div{{font-family:'NVIDIA Sans',sans-serif!important}}</style>"


class Viewer:
    def __init__(self,title):
        self.server=viser.ViserServer(host='127.0.0.1',port=8890,verbose=False)
        self.server.gui.configure_theme(dark_mode=False,show_logo=False,show_share_button=False,
                                       control_layout='collapsible',control_width='small',brand_color=(118,185,0))
        self.server.gui.add_html(font_css())
        self.server.gui.add_markdown('### '+title)
        scene=self.server.scene
        scene.set_up_direction('+z')
        scene.world_axes.visible=False
        # Viser 1.0.30 embeds this HDRI in its wheel; it makes no CDN request.
        scene.configure_environment_map('studio',background=False,environment_intensity=.65)
        scene.configure_default_lights(enabled=False,cast_shadow=False)
        scene.add_light_directional("/lighting/key",intensity=.9,position=(1,-2,3),wxyz=(.92388,.38268,0,0))
        scene.add_light_ambient('/lighting/fill',intensity=.18)
        y=np.linspace(0,1,512)[:,None,None]
        gradient=(np.array([226,223,216])[None,None,:]*(1-y)+np.array([247,245,240])[None,None,:]*y)
        scene.set_background_image(np.repeat(gradient.astype(np.uint8),1024,axis=1),format='jpeg')
        self.closed=threading.Event()
        self.camera_position=(.90,-1.90,1.62)
        self.camera_target=(0.,-.50,1.08)
        @self.server.on_client_connect
        def connected(client):
            client.camera.position=self.camera_position
            client.camera.look_at=self.camera_target
            client.camera.up_direction=(0,0,1)
            client.camera.fov=np.deg2rad(42)

    def camera(self,position,target):
        self.camera_position=tuple(position);self.camera_target=tuple(target)
        for client in self.server.get_clients().values():
            client.camera.position=self.camera_position;client.camera.look_at=self.camera_target

    def show(self,height=610):
        url=f'http://127.0.0.1:{self.server.get_port()}'
        display(HTML(f'<a href="{url}" target="_blank">Open this 3D viewer in a separate tab</a>'))
        display(IFrame(src=url,width='100%',height=height))
        return self

    def close(self):
        if self.closed.is_set():return
        self.closed.set()
        if hasattr(self,'thread'):self.thread.join(timeout=2)
        self.server.stop()

    def add_robot(self,kinematics,prefix='/robot',hands_only=False):
        handles={}
        for path in sorted((ASSETS/'visuals').glob('*.glb')):
            name=path.stem
            if name=='flask':continue
            if hands_only and not (name.startswith(('left_','right_')) or name in ('Link7_L','Link7_R')):continue
            try:body=kinematics.body_ids['Marvin_pro_809_'+name]
            except KeyError:continue
            handles[body]=self.server.scene.add_glb(prefix+'/'+name,mesh_bytes(path.name),receive_shadow=False,cast_shadow=False)
        return handles

    def text_label(self,name,text,position,size=.036):
        """Vector NVIDIA Sans geometry; independent of browser label fonts."""
        normal=np.asarray(self.camera_position)-np.asarray(position);normal/=np.linalg.norm(normal)
        right=np.cross([0,0,1],normal);right/=np.linalg.norm(right)
        up=np.cross(normal,right)
        quat=Rotation.from_matrix(np.column_stack([right,up,normal])).as_quat()[[3,0,1,2]]
        return self.server.scene.add_glb(name,(ASSETS/'labels'/(text+'.glb')).read_bytes(),
            scale=size,position=position,wxyz=quat,cast_shadow=False,receive_shadow=False)

    def playback(self,rollout):
        self.sim=Kinematics()
        handles=self.add_robot(self.sim)
        flask=self.server.scene.add_glb('/flask',mesh_bytes('flask.glb'))
        table=trimesh.creation.box(extents=(1.,.6,.025))
        self.server.scene.add_mesh_simple('/table/top',table.vertices,table.faces,color=(195,198,195),position=(.05,-.8,.7375))
        for i,(x,y) in enumerate([(-.39,-1.04),(.49,-1.04),(-.39,-.56),(.49,-.56)]):
            leg=trimesh.creation.box(extents=(.035,.035,.72))
            self.server.scene.add_mesh_simple(f'/table/leg{i}',leg.vertices,leg.faces,color=(108,115,113),position=(x,y,.36))
        self.server.gui.add_markdown(f'{rollout.mode}  \n**20 Hz** control · **200 Hz** physics  \n{rollout.reason or "Full reference"}')
        playing=self.server.gui.add_checkbox('Play',initial_value=False)
        speed=self.server.gui.add_dropdown('Playback speed',options=('0.5×','1×','2×','4×'),initial_value='1×')
        slider=self.server.gui.add_slider('Frame',min=0,max=len(rollout.qpos)-1,step=1,initial_value=0)
        status=self.server.gui.add_markdown('')
        def update(index):
            self.sim.set_pose(rollout.qpos[index])
            with self.server.atomic():
                for body,handle in handles.items():handle.position=self.sim.positions[body];handle.wxyz=self.sim.quaternions[body]
                flask.position=self.sim.positions[self.sim.object_id];flask.wxyz=self.sim.quaternions[self.sim.object_id]
            status.content=f't = **{rollout.frames[index]/20:.2f} s**  \nObject error: {rollout.object_error[index]*1000:.1f} mm'
        @slider.on_update
        def changed(_):update(int(slider.value))
        def loop():
            while not self.closed.wait(1/20):
                if playing.value:
                    advance=float(speed.value[:-1])
                    self.cursor=(self.cursor+advance)%len(rollout.qpos)
                    slider.value=int(self.cursor)
                else:self.cursor=float(slider.value)
        self.cursor=0.;update(0)
        self.thread=threading.Thread(target=loop,daemon=True);self.thread.start()
        return self

    def contact_scene(self):
        mu=.1
        self.sim=Kinematics()
        self.camera((1.05,-1.55,.90),(0.,0.,.12))
        scene=self.server.scene
        root=scene.add_frame('/reference',show_axes=False,position=(0,0,.22),wxyz=self.sim.ref_q[0,61:65])
        hands=self.add_robot(self.sim,prefix='/reference/hands',hands_only=True)
        scene.add_glb('/reference/flask',mesh_bytes('flask.glb'))
        slider=self.server.gui.add_slider('Reference frame', min=0, max=self.sim.num_frames-1, step=1, initial_value=250)
        self.contact_slider=slider
        self.contact_frame=None
        visible_hands=self.server.gui.add_checkbox('Show hands',initial_value=True)
        self.server.gui.add_markdown('**Left** = blue · **Right** = orange  \nShort arrows point inward to the contact.  \nContact labels: reference proximity ≤10 mm.  \nDisplay cone slope = 0.45; calculation μ = '+str(mu)+'.')
        status=self.server.gui.add_markdown('')
        dynamic=[]
        redraw=threading.Event()
        draw_lock=threading.Lock()
        # Static axes and labels remain fixed while the contact surfaces change.
        for side in ('left','right'):
            origin=np.array([-.37 if side=='left' else .37,0.,-.20])
            for axis,c in enumerate(((200,68,68),(74,148,80),(72,109,204))):
                end=np.zeros(3);end[axis]=.35
                scene.add_arrows(f'/axes/{side}/{axis}',np.array([[np.zeros(3),end]]),colors=c,position=origin,shaft_radius=.003,head_radius=.009,head_length=.025)
                self.text_label(f'/labels/{side}/{axis}','xyz'[axis],origin+end*1.07)
            self.text_label('/labels/'+side+'_title',side.title(),origin+np.array([0,-.07,-.28]),size=.045)
        def draw(frame):
            frame_data=load_frame(frame,mu=mu)
            for handle in dynamic:handle.remove()
            dynamic.clear()
            self.sim.set_pose(self.sim.ref_q[frame])
            pos=self.sim.positions[self.sim.object_id];quat=self.sim.quaternions[self.sim.object_id];rot=self.sim.rotations[self.sim.object_id].reshape(3,3)
            for body,handle in hands.items():
                handle.position=rot.T@(self.sim.positions[body]-pos);handle.wxyz=relative_quat(quat,self.sim.quaternions[body]);handle.visible=visible_hands.value
            for i,side in enumerate(('left','right')):
                data=frame_data[side];color=COLORS[side];points=data['points'];normals=data['normals']
                if not len(points):
                    continue
                mesh=trimesh.Trimesh(data['vertices'],data['faces'],process=True)
                mesh.update_faces(mesh.nondegenerate_faces());mesh.remove_unreferenced_vertices()
                dynamic.append(scene.add_point_cloud('/reference/'+side+'/points',points,colors=color,point_size=.006,point_shape='circle'))
                dynamic.append(scene.add_arrows('/reference/'+side+'/normals',np.stack([points-.04*normals,points],axis=1),colors=color,shaft_radius=.0009,head_radius=.0025,head_length=.007))
                for k,(p,n) in enumerate(zip(points,normals)):
                    # Cone apex at contact, base outside the object; wider only for legibility.
                    cone=trimesh.creation.cone(radius=.04*.45,height=.04,sections=16)
                    cone.vertices[:,2]-=.04
                    transform=trimesh.geometry.align_vectors([0,0,1],n)
                    cone.apply_transform(transform);cone.apply_translation(p)
                    dynamic.append(scene.add_mesh_simple(f'/reference/{side}/cone{k}',cone.vertices,cone.faces,color=color,opacity=.20,side='double',cast_shadow=False))
                origin=np.array([-.37 if side=='left' else .37,0.,-.20]);scale=.17
                dynamic.append(scene.add_mesh_simple('/wrench/'+side,mesh.vertices*scale,mesh.faces,color=color,position=origin,side='double',cast_shadow=False))
            status.content=f'Frame **{frame} / {self.sim.num_frames-1}** · t = **{frame/20:.2f} s**'
            self.contact_frame=frame
        @slider.on_update
        def changed(_):redraw.set()
        @visible_hands.on_update
        def changed_hands(_):
            for handle in hands.values():handle.visible=visible_hands.value
        draw(int(slider.value))
        def scrub():
            while not self.closed.wait(.02):
                if not redraw.is_set():continue
                redraw.clear()
                frame=int(slider.value)
                with draw_lock, self.server.atomic():draw(frame)
        self.thread=threading.Thread(target=scrub,daemon=True);self.thread.start()
        return self
