# V2D workshop

[Workshop page](https://nvidia-isaac.github.io/video_to_data/v2d_corl_tutorial/) · [Video to Data repository](https://github.com/nvidia-isaac/video_to_data/)

Extract the entire ZIP. Install **Python 3.12** with pip and venv support, then
open Terminal or PowerShell in the extracted `V2D_workshop` folder.

## Open the notebook

Only Python and Jupyter Notebook must be set up outside the notebook. The notebook's
first setup cell installs the remaining workshop dependencies. Use local
Jupyter Notebook; the live viewers are not supported in cloud-hosted notebooks.

**macOS / Linux — first time**

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install notebook==7.5.5 ipykernel==7.4.0
jupyter notebook V2D_workshop.ipynb
```

**Windows (PowerShell) — first time**

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install notebook==7.5.5 ipykernel==7.4.0
.\.venv\Scripts\jupyter.exe notebook V2D_workshop.ipynb
```

Run **Setup**, then the five workshop cells in order with **Shift+Enter**.
Installation needs internet the first time. Keep the terminal and notebook
kernel running for live viewers. First-time kernel/model initialization can
also take longer. No GPU or training is needed.

## Later launches

From the same folder, use the commands for your platform. On macOS/Linux,
activation is needed once per new terminal; after that, just run `jupyter notebook`:

```bash
# macOS / Linux
source .venv/bin/activate
jupyter notebook V2D_workshop.ipynb
```

```powershell
# Windows
.\.venv\Scripts\jupyter.exe notebook V2D_workshop.ipynb
```

You can run the setup cell again; matching installed versions are retained.
After updating workshop code, reload the notebook from disk and restart the kernel.

Physics runs through Newton on CPU. The training
section only prints a reference command. Model assets are included locally.
Apple Silicon macOS 14+, Windows x64, and Linux x64 with glibc 2.35+ are the
package targets. The workshop has been tested on Apple M4 / macOS 26.7.1.
