# Kaggle metric leaderboards

Open each competition to accept its rules before submitting.

## Track 1: reconstruction

| Group | Metric | Kaggle leaderboard |
| --- | --- | --- |
| Track 1 | CD-H | [v2d-challenge-track1-cd-h](https://www.kaggle.com/competitions/v2d-challenge-track1-cd-h/leaderboard) |
| Track 1 | CD-O | [v2d-challenge-track1-cd-o](https://www.kaggle.com/competitions/v2d-challenge-track1-cd-o/leaderboard) |
| Track 1 | ACC-H | [v2d-challenge-track1-acc-h](https://www.kaggle.com/competitions/v2d-challenge-track1-acc-h/leaderboard) |
| Track 1 | ACC-O | [v2d-challenge-track1-acc-o](https://www.kaggle.com/competitions/v2d-challenge-track1-acc-o/leaderboard) |
| Track 1 | PEN | [v2d-challenge-track1-pen](https://www.kaggle.com/competitions/v2d-challenge-track1-pen/leaderboard) |

## Track 2: robotic grounding

| Group | Metric | Kaggle leaderboard |
| --- | --- | --- |
| Track 2 · Tier 1 | AUC | [v2d-challenge-track2-tier1-auc](https://www.kaggle.com/competitions/v2d-challenge-track2-tier1-auc/leaderboard) |
| Track 2 · Tier 1 | SP-SR | [v2d-challenge-track2-tier1-sp-sr](https://www.kaggle.com/competitions/v2d-challenge-track2-tier1-sp-sr/leaderboard) |
| Track 2 · Tier 1 | MP-SR | [v2d-challenge-track2-tier1-mp-sr](https://www.kaggle.com/competitions/v2d-challenge-track2-tier1-mp-sr/leaderboard) |
| Track 2 · Tier 1 | MPPE | [v2d-challenge-track2-tier1-mppe](https://www.kaggle.com/competitions/v2d-challenge-track2-tier1-mppe/leaderboard) |
| Track 2 · Tier 2 | AUC | [v2d-challenge-track2-tier2-auc](https://www.kaggle.com/competitions/v2d-challenge-track2-tier2-auc/leaderboard) |
| Track 2 · Tier 2 | SP-SR | [v2d-challenge-track2-tier2-sp-sr](https://www.kaggle.com/competitions/v2d-challenge-track2-tier2-sp-sr/leaderboard) |
| Track 2 · Tier 2 | MP-SR | [v2d-challenge-track2-tier2-mp-sr](https://www.kaggle.com/competitions/v2d-challenge-track2-tier2-mp-sr/leaderboard) |
| Track 2 · Tier 2 | MPPE | [v2d-challenge-track2-tier2-mppe](https://www.kaggle.com/competitions/v2d-challenge-track2-tier2-mppe/leaderboard) |
| Track 2 · Tier 3 | AUC | [v2d-challenge-track2-tier3-auc](https://www.kaggle.com/competitions/v2d-challenge-track2-tier3-auc/leaderboard) |
| Track 2 · Tier 3 | SP-SR | [v2d-challenge-track2-tier3-sp-sr](https://www.kaggle.com/competitions/v2d-challenge-track2-tier3-sp-sr/leaderboard) |
| Track 2 · Tier 3 | MP-SR | [v2d-challenge-track2-tier3-mp-sr](https://www.kaggle.com/competitions/v2d-challenge-track2-tier3-mp-sr/leaderboard) |
| Track 2 · Tier 3 | MPPE | [v2d-challenge-track2-tier3-mppe](https://www.kaggle.com/competitions/v2d-challenge-track2-tier3-mppe/leaderboard) |

## Track 3: end-to-end

| Group | Metric | Kaggle leaderboard |
| --- | --- | --- |
| Pose | AUC | [v2d-challenge-track3-auc](https://www.kaggle.com/competitions/v2d-challenge-track3-auc/leaderboard) |
| Pose | SP-SR | [v2d-challenge-track3-sp-sr](https://www.kaggle.com/competitions/v2d-challenge-track3-sp-sr/leaderboard) |
| Pose | MP-SR | [v2d-challenge-track3-mp-sr](https://www.kaggle.com/competitions/v2d-challenge-track3-mp-sr/leaderboard) |
| Pose | RPE | [v2d-challenge-track3-rpe](https://www.kaggle.com/competitions/v2d-challenge-track3-rpe/leaderboard) |
| Pose | MPPE | [v2d-challenge-track3-mppe](https://www.kaggle.com/competitions/v2d-challenge-track3-mppe/leaderboard) |
| Mesh | CD-O | [v2d-challenge-track3-cd-o](https://www.kaggle.com/competitions/v2d-challenge-track3-cd-o/leaderboard) |
