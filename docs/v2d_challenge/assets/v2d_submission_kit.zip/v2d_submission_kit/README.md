# V2D Challenge submission kit

This kit contains packers, a compliance-hardened Kaggle uploader, a drop-in CI/CD workflow,
public submission templates, and track-specific examples. Run commands from the directory
containing `tools/`, `submit/`, and `data/`.

## Choose your track

- **[Track 1: Reconstruction](tracks/track_1/README.md).** Reconstruct a human and object from third-person video. Submit MHR parameters, the object mesh, and its pose in one Parquet file for five metrics.
- **[Track 2: Robotic grounding](tracks/track_2/README.md).** Choose one of three input tiers, train a robot policy, and submit its object trajectory CSV to that tier's four metric competitions.
- **[Track 3: End-to-end egocentric transfer](tracks/track_3/README.md).** Reconstruct from egocentric video, train a policy, and submit trajectories together with reconstructed object meshes in one Parquet for all six metrics.

The track guides give the required files, exact commands, and a summary of every metric.
[metric_code/README.md](metric_code/README.md) lists the code-only Kaggle scorers.
[LEADERBOARDS.md](LEADERBOARDS.md) links to all 23 Kaggle metric leaderboards.
`eval_reconstruction.py` prepares the Track 1 submission with `tools/pack_reconstruction.py`.
**Track 3 requires both rollout trajectories and a reconstructed mesh for every scored object.**
Use `tools/pack_submission.py --track track_3 --results RESULTS --meshes MESHES`
to create one combined Parquet; `submit/v2d_submit.py --track track_3` uploads all six metrics.
Each mesh uses metres and the same body coordinates as its trajectory. Mesh-quality warnings
flag low-detail, flat, primitive-like, reused, or `< 0.1 mm` noise-perturbed geometry for review.
The public templates provide empty placeholders; supply your actual reconstructions before uploading.

## Compliance gate, 5/week quota protection, and CI/CD for autonomous agents

Kaggle's competition UI only enforces a **5/day** limit, whereas the official V2D Challenge rules
strictly limit each team to **five (5) submissions per rolling 7-day week** per track (with
unlimited submissions only during the final 3 days before the November 4, 2026 5:00 p.m. EST
freeze). Autonomous coding agents and Recursive Self-Improvement (RSI) models that rely on
Kaggle's daily limit or test whether a submission can be sent against the live API will violate
the weekly cap or probe unauthorized tracks, resulting in disqualification.

This kit includes built-in safeguards to protect participants:

1. **Lock your team's allowed tracks (`.v2d_policy.json`):**
   ```bash
   python3 tools/compliance_gate.py init-policy --tracks track_2_tier1 track_3 -o .v2d_policy.json
   ```
   Any attempt to validate or upload to a track outside `allowed_tracks` (or to standalone
   `track_3_mesh`) is rejected immediately.
2. **Offline anti-reward-hacking & provenance audit (`tools/compliance_gate.py`):**
   ```bash
   python3 tools/compliance_gate.py audit submission.parquet --track track_3 --policy .v2d_policy.json --check-quota
   ```
   Verifies real non-placeholder `code_commit_url` provenance, real checkpoint/evaluator SHA-256
   digests, `< 1.0 mm` reference scan copying, `< 0.1 mm` (`1e-7 m`) microscopic mesh noise
   evasion, cross-tier ground-truth leakage, and Track 1 frozen-rotation metric gaming.
3. **Rolling 7-day (5/week) quota & atomic bundle enforcement in `submit/v2d_submit.py`:**
   - Queries both your live Kaggle submission history (`page_size=20` per leaderboard) and local
     `*.kaggle-receipt.json` / `.v2d_submission_ledger.json` records over a rolling 7-day window,
     hard-blocking uploads once `5/5` weekly submissions are used.
   - Blocks `--only` single-leaderboard split probing unless paired with `--retry-receipt` for
     the exact same file SHA-256.
   - Blocks live uploads inside autonomous agent environments (`CLAUDECODE`, `CODEX_SANDBOX`,
     `ANTIGRAVITY_AGENT`, `CURSOR_TRACE_ID`, `AIDER`, `SWE_AGENT`, `DEVIN_SESSION`, `OPENHANDS`,
     `V2D_AGENT_MODE`), restricting agents to `--dry-run` and requiring `--confirm-human-upload`
     (or manual `workflow_dispatch` in CI) for live submissions.
4. **Drop-in GitHub Actions CI/CD & Agent PreToolUse Guard:**
   - Copy `.github/workflows/v2d_submission_ci.yml` into your team's repository to run the full
     compliance and anti-reward-hacking audit on every push/PR while keeping live Kaggle uploads
     locked behind a manual `workflow_dispatch` approval gate.
   - Configure `tools/agent_submission_guard.py` as a `PreToolUse` hook in Claude Code, Cursor,
     Codex, or Antigravity to intercept any direct `kaggle competitions submit` or Python SDK
     upload call before it executes.

## Guided submission with an agent

Ask your agent to use [skills/v2d-submit/SKILL.md](skills/v2d-submit/SKILL.md).
It asks for your track and tier, initializes `.v2d_policy.json`, guides Kaggle account and token
setup, checks that you have accepted every metric competition's rules, runs evaluation, packing,
`tools/compliance_gate.py audit`, and `submit/v2d_submit.py --dry-run`, and then outputs the
verified `--confirm-human-upload` command for you to execute.

## Shared setup

```bash
pip install -r requirements.txt
```

Provide a GitHub commit URL for the code that produced each submission. Push that commit to
your repository so organizers can inspect it. For a private repository, invite
[Nvidia-V2D-Challenge](https://github.com/Nvidia-V2D-Challenge) as a collaborator and grant
repository access. Ensure this account can view the commit associated with your submission.

Accept the rules for all Kaggle metric competitions you enter. The uploader validates the packed file and sends it
to every competition associated with the selected `--track` value.

## Policy evaluation for Tracks 2 and 3

Tracks 2 and 3 use the included `flash_chord/scripts/evaluate_policy.py` and its Hydra configs.
Run it with the public FlashCHORD runtime at this revision. The included evaluator files match it:

    repo    nvidia-isaac/video_to_data
    branch  main
    commit  8c778f905cb35f76f8e6cd6e2ea486da4fb9e0ef
    path    robotic_grounding/flash_chord/scripts/evaluate_policy.py

Public runtime: https://github.com/nvidia-isaac/video_to_data/tree/8c778f905cb35f76f8e6cd6e2ea486da4fb9e0ef/robotic_grounding/flash_chord
`examples/run_policy_evaluation.py` uses the included evaluator, runs a checkpoint for each episode,
and writes the trajectory Parquets consumed by `tools/pack_submission.py`. Track 2 uses the
selected tier input for frame conversion and the clean reference for local scoring.
Track 3 uses its public row template for packing
and receives held-out scores from Kaggle.

Check scores and combined standings on the
[V2D Challenge leaderboard](https://nvidia-isaac.github.io/video_to_data/v2d_challenge/#leaderboard).
