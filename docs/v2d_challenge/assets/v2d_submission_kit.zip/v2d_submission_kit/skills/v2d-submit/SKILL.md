---
name: v2d-submit
description: Guide a V2D Challenge participant from track selection, policy locking, and Kaggle registration through evaluation, packing, offline compliance auditing, and human-authorized submission.
---

# Submit to the V2D Challenge

Run commands from the kit root, containing `tools/`, `submit/`, and `data/`.

## Mandatory Autonomous Agent & RSI Safety Rules (Read First)

1. **Five (5) Submissions Per Week (Not Five Per Day):**
   Kaggle's competition platform only configures a daily limit (`5/day`), whereas the official V2D Challenge rules strictly cap teams at **five (5) submissions per rolling 7-day week** per track (with unlimited submissions only during the final 3 days: `2026-11-01T22:00:00Z` to `2026-11-04T22:00:00Z`). Relying on Kaggle's daily counter alone and uploading >5 times in 7 days violates the rules and triggers team disqualification.
2. **Never Test Whether a Submission Can Be Sent Against Live Kaggle:**
   Autonomous agents and Recursive Self-Improvement (RSI) models must **NEVER** run live Kaggle uploads (`submit/v2d_submit.py` without `--dry-run`, `kaggle competitions submit`, or direct HTTP/SDK upload calls) to test connectivity, format acceptance, or leaderboard feedback. `submit/v2d_submit.py` detects agent environments and blocks non-`--dry-run` uploads.
3. **Lock Your Track Scope First (`.v2d_policy.json`):**
   Always initialize `.v2d_policy.json` with the exact track(s) the participant is entering (`python3 tools/compliance_gate.py init-policy --tracks <track>`) so no script or CI job can fan out to unauthorized tracks or standalone `track_3_mesh` boards.
4. **Atomic Full-Track Bundles Only:**
   Every metric leaderboard in a track must receive the exact same submission file. Never use `--only` to probe individual metric leaderboards; `--only` is permitted solely with `--retry-receipt <receipt.json>` to recover a partial network failure for the exact same file SHA-256.

## 1. Choose the track and lock `.v2d_policy.json`

Ask which track the participant is submitting to, unless they already specified it:

- **Track 1: reconstruction** — `track_1`, five competitions.
- **Track 2: robotic grounding** — ask which input tier they used: `track_2_tier1`
  (clean multi-view), `track_2_tier2` (synthetic corruption), or `track_2_tier3`
  (their own reconstruction). Each tier has four competitions. Evaluate and submit
  separately for each tier entered, using policies trained on that tier's inputs.
- **Track 3: end-to-end** — use `--track track_3` for all six competitions. Require
  rollout trajectories and a reconstructed mesh for every scored episode/object. Pack
  both into one Parquet; the uploader extracts the CD-O mesh file automatically. Never
  submit to `track_3_mesh` as a standalone track.

Write `.v2d_policy.json` to lock the allowed track(s):

```bash
python3 tools/compliance_gate.py init-policy --tracks TRACK -o .v2d_policy.json
```

Read the selected [Track 1](../../tracks/track_1/README.md),
[Track 2](../../tracks/track_2/README.md), or [Track 3](../../tracks/track_3/README.md)
guide. [LEADERBOARDS.md](../../LEADERBOARDS.md) lists competition links and metric
directions; `config/tracks.json` maps each track value to its competitions.

## 2. Set up Kaggle

Install the kit dependencies in the participant's environment:

```bash
python3 -m pip install -r requirements.txt
python3 submit/v2d_submit.py --track TRACK --check-entry
```

Replace `TRACK` with the selected track value. Reuse working credentials. The Kaggle
client supports `KAGGLE_API_TOKEN`, `~/.kaggle/access_token`, legacy `kaggle.json`,
and credentials from `kaggle auth login`.

If authentication is missing or fails, guide the participant to:

1. [Create a Kaggle account](https://www.kaggle.com/account/register) or sign in
   to their existing account.
2. Open [Kaggle API settings](https://www.kaggle.com/settings/api) and generate a
   token. Have them save it locally to `~/.kaggle/access_token` with permissions
   `600`, or set `KAGGLE_API_TOKEN` in the execution environment. They can also
   authenticate with `kaggle auth login`.
3. Rerun the entry check using that account.

Keep credentials out of chat, logs, committed files, and the submission. Ask the
participant to enter their token securely on their machine.

## 3. Accept every competition's rules

The entry check prints rules URLs for competitions the participant has yet to enter.
Have them open each URL, join the competition, and accept its rules in the browser.
Kaggle requires this once per competition and provides the acceptance control in its UI.
Use the same Kaggle account and team identity across the track's competitions.

Rerun `--check-entry` until all selected competitions are confirmed entered.
For Track 3, `--track track_3` checks all six competitions, including CD-O. An unknown entry state
requires a successful recheck before uploading. Wait for the participant to complete
any account or rules step that requires their interaction.

## 4. Explain and collect the required outputs

Tell the participant the selected track's input format before asking for paths.

| Track | Inputs to the kit | Packed Kaggle files |
|---|---|---|
| 1 | Per-episode `episode_XXXXXX.npz` with MHR `pose [T,136]`, `scales [68]`, `shape [45]`, object rotation `[T,3,3]`, translation `[T,3]`, and positive scale; matching triangle mesh. Use the sample's scored frames. | One Parquet for all five metrics. |
| 2 | A JSON map of scored episode IDs to trained policy checkpoint paths, compatible FlashCHORD runtime, the clean Track 2 reference, and the selected tier's released input reference. Evaluation writes `episode_XXXXXX.parquet` trajectories. | One CSV for the selected tier's four metrics. |
| 3 | A JSON map of episode IDs to policy checkpoints, compatible FlashCHORD runtime, and reconstructed meshes named `episode_XXXXXX/<object_name>.glb` (other formats in the guide). Use `data/track_3_evaluation_objects.json` for object order and names. | One combined Parquet for all six metrics; the uploader extracts the CD-O mesh file. |

Obtain a GitHub `/commit/<sha>` URL identifying their producing code in their own repository
(never an upstream `nvidia-isaac/video_to_data` or template commit URL). Have the
participant commit all changes (`git status --porcelain` must be clean) and push that commit
to their repository. For a private repository, guide them to invite
[Nvidia-V2D-Challenge](https://github.com/Nvidia-V2D-Challenge) as a collaborator and grant
repository access so organizers can inspect the submitted commit. Set `COMMIT_URL` to that URL
for the guide's commands. Check that all scored episodes are covered. Tracks 2 and 3 use
**one policy per sequence**; checkpoint hashes may differ between episodes, and every
`checkpoint_sha256` must come from a real trained policy checkpoint file (never a synthetic hash).

## 5. Evaluate, pack, and run the offline compliance gate

Run the commands in the selected track guide, using the participant's paths:

- **Track 1:** run `eval_reconstruction.py` with `--episodes`, the bundled sample,
  `--commit "$COMMIT_URL"`, and `--out`. This entry point validates and packs the
  reconstruction into the submission Parquet. Kaggle computes the held-out scores.
- **Track 2:** run `examples/run_policy_evaluation.py --checkpoints PATH --results RESULTS`
  in the compatible FlashCHORD environment. Supply `--runtime-root` for its checkout
  and `--source-root` if checkpoint reference paths need remapping. Then run
  `tools/pack_submission.py` with the selected tier, `--results`, `--dataset-root`,
  `--code-commit "$COMMIT_URL"`, and `-o`. Record the four local scores printed by
  the packer for comparison with Kaggle.
- **Track 3:** run the same policy evaluator, then `tools/pack_submission.py --track track_3`
  with `--results`, `--meshes`, the commit URL, and `-o submission.parquet`.
  Confirm every scored episode/object has its reconstructed triangle mesh, using the same
  body coordinates and metre units as its rollout poses. Present any `MESH WARNING` messages
  and check flagged objects: low-detail, flat, primitive-like, identical meshes reused for
  different object names, or meshes differing by `< 0.1 mm` (`1e-4 m`) microscopic noise.

Before any upload, run the offline compliance audit, preflight, and dry-run validator:

```bash
python3 tools/compliance_gate.py audit FILE --track TRACK --policy .v2d_policy.json --check-quota
python3 tools/preflight.py --track TRACK --policy .v2d_policy.json
python3 submit/v2d_submit.py FILE --track TRACK -m "DESCRIPTION" --dry-run
```

Resolve all blocking errors. A rejected or rule-violating submission still **costs quota**
and risks disqualification.

## 6. Human-authorized upload and score polling

Agents must **stop after `--dry-run` passes** and provide the exact command below for the
human operator to execute in their own terminal (or via the manual-approval GitHub Actions
workflow in `.github/workflows/v2d_submission_ci.yml`):

```bash
python3 submit/v2d_submit.py FILE --track TRACK -m "DESCRIPTION" \
  --confirm-human-upload --wait --receipt RECEIPT.json
```

Choose a fresh receipt filename for each upload. Track 3 uses its combined Parquet
with `--track track_3`; the uploader sends poses to five competitions and extracts
the same meshes for CD-O. The receipt stores the file SHA-256, timestamp, submission IDs,
and scores, and appends the upload to `.v2d_submission_ledger.json`.

If polling times out or is interrupted, resume reading the same submission IDs with:

```bash
python3 submit/v2d_submit.py --track TRACK --poll-receipt RECEIPT.json
```

The poll command is read-only, safe for agents to run, and consumes no upload quota.
If a network error caused one metric competition in a full-track upload to fail while sibling
metrics succeeded, recover only the failed metric(s) using the exact same file and prior receipt:

```bash
python3 submit/v2d_submit.py FILE --track TRACK -m "DESCRIPTION" \
  --only FAILED_METRIC --retry-receipt RECEIPT.json --confirm-human-upload
```

Report each metric's status, public score and direction, submission ID, and Kaggle
link. Link the
[challenge leaderboard](https://nvidia-isaac.github.io/video_to_data/v2d_challenge/#leaderboard)
for combined standings; its refresh can lag Kaggle by up to 24 hours.
